##################################################
Data source: https://trec.nist.gov
The TREC dataset is dataset for question classification consisting of open-domain, fact-based questions divided into broad semantic categories. It has both a six-class (TREC-6) and a fifty-class (TREC-50) version. Both have 5,452 training examples and 500 test examples 
##################################################
Data pre-processing courtesy of: Alberto Blanco
If you use these data, please, cite: 
Blanco, Alberto, et al. "Extracting Cause of Death from Verbal Autopsy with Deep Learning interpretable methods." IEEE Journal of Biomedical and Health Informatics (2020).
##################################################