##################################################
Task and related work:
https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1002486
https://www.ncbi.nlm.nih.gov/pmc/articles/PMC6030395/#ref-4

##################################################
Data source:
http://doi.org/10.17605/OSF.IO/XUK5Q


Data pre-processing courtesy of: Alberto Blanco
If you use these data, please, cite: 
Blanco, Alberto, et al. "Extracting Cause of Death from Verbal Autopsy with Deep Learning interpretable methods." IEEE Journal of Biomedical and Health Informatics (2020).
##################################################